from collections import deque

def sorted_deque(values):
    sorted_values = sorted(values) 
    dq = deque(sorted_values) 
    return dq

values = [5, 3, 8, 1, 4]
dq = sorted_deque(values)
print("Sorted deque:", dq)
