listOne = [3, 6, 9, 12, 15, 18, 21]
listTwo = [4, 8, 12, 16, 20, 24, 28]

odd_index_elements = [listOne[i] for i in range(len(listOne)) if i % 2 == 1]

even_elements = [num for num in listTwo if num % 2 == 0]

result_list = odd_index_elements + even_elements

print("Resulting list:", result_list)
     