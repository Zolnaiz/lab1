from ultralytics import YOLO
from PIL import Image

model = YOLO("yolo11n.pt")

image_path = r"R.jpg"

try:
    results = model.predict(image_path)
    result = results[0]

    if len(result.boxes) == 0:
        print("⚠️ No objects detected in the image.")
    else:
        box = result.boxes[0]
        cords = [round(x.item()) for x in box.xyxy[0]]
        conf = round(box.conf[0].item(), 2)
        class_id = result.names[box.cls[0].item()]

        print("First detected object:")
        print("Object type:", class_id)
        print("Coordinates:", cords)
        print("Probability:", conf)
        count = 0
        print("\nAll detections:")
        for box in result.boxes:
            cords = [round(x.item()) for x in box.xyxy[0]]
            conf = round(box.conf[0].item(), 2)
            class_id = result.names[box.cls[0].item()]
            
            count += 1
            print("Object type:", class_id)
            print("Coordinates:", cords)
            print("Probability:", conf)
            print("---")

        print(f"Total objects detected: {count}")

        Image.fromarray(result.plot()).show()

except Exception as e:
    print(f"❌ Error during prediction: {e}")
