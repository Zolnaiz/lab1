import cv2
import pytesseract
import pandas as pd
import difflib
import os

pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

def preprocess_image(image_path):
    img = cv2.imread(image_path)
    img = cv2.resize(img, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.fastNlMeansDenoising(gray, None, 30, 7, 21)
    adaptive_thresh = cv2.adaptiveThreshold(
        gray, 255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        31, 2
    )
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2))
    morph = cv2.morphologyEx(adaptive_thresh, cv2.MORPH_CLOSE, kernel)
    return morph

def extract_text_from_image(image):
    custom_config = r'--oem 3 --psm 6'
    return pytesseract.image_to_string(image, config=custom_config)

def evaluate(pred_text, true_text):
    pred = pred_text.strip().replace('\n', ' ').lower()
    true = true_text.strip().replace('\n', ' ').lower()

    matcher = difflib.SequenceMatcher(None, true, pred)
    similarity = matcher.ratio()

    return round(similarity * 100, 2)

image_folder = 'images'
image_files = [f for f in os.listdir(image_folder) if f.endswith('.jpg') or f.endswith('.png')]

results = []

for file in image_files:
    image_path = os.path.join(image_folder, file)
    txt_path = os.path.join(image_folder, file.replace('.jpg', '.txt').replace('.png', '.txt'))

    image = preprocess_image(image_path)
    predicted_text = extract_text_from_image(image)

    with open(txt_path, 'r', encoding='utf-8') as f:
        ground_truth = f.read()

    acc = evaluate(predicted_text, ground_truth)

    print(f"\n{file}")
    print("Predicted Text:", predicted_text.strip())
    print("Ground Truth:", ground_truth.strip())
    print(f" Similarity: {acc}%")

    results.append({
        'Image': file,
        'Predicted Text': predicted_text.strip(),
        'Ground Truth': ground_truth.strip(),
        'Similarity (%)': acc
    })

df = pd.DataFrame(results)
print("\n ҮР ДҮН:")
print(df)
