import google.generativeai as genai
from dotenv import load_dotenv
import os

# .env ачааллах
load_dotenv()
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))

# Загвар тохируулах
model = genai.GenerativeModel("gemini-1.5-flash")  # эсвэл gemini-2.0-flash, хэрвээ эрхтэй бол

# Чатбот хариулт өгөх функц
def ask_ai(question):
    try:
        response = model.generate_content(
            question,
            generation_config=genai.types.GenerationConfig(
                candidate_count=1,
                temperature=0.5
            )
        )
        return response.text.strip()
    except Exception as e:
        return f"⚠️ Алдаа гарлаа: {e}"

# Интерактив чатбот ажиллуулах
def run_chatbot():
    print("🤖 Gemini Flash Chatbot руу тавтай морил!")
    print("Асуултаа бичнэ үү (жишээ нь: 'Монголын нийслэл юу вэ?', 'x + 5 = 12 хэд вэ?', 'AI гэж юу вэ?').")
    print("Гарахын тулд 'гар' гэж бичээрэй.\n")

    while True:
        question = input("📥 Та: ")
        if question.lower() in ['гар', 'exit', 'quit']:
            print("👋 Баяртай!")
            break

        answer = ask_ai(question)
        print(f"🤖 Хариу: {answer}\n")

if __name__ == "__main__":
    run_chatbot()
