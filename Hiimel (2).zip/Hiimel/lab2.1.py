class Stack:
    def __init__(self):
        self.stack = []

    def push(self, element):
        self.stack.append(element)

    def pop(self):
        if not self.is_empty():
            return self.stack.pop()
        else:
            print("Stack hooson baina.")
            return None

    def top(self):
        if not self.is_empty():
            return self.stack[-1]
        else:
            print("Stack hooson baina.")
            return None

    def __len__(self):
        return len(self.stack)

    def length(self):
        return len(self)

    def is_empty(self):
        return len(self.stack) == 0

    def __str__(self):
        return "Stack: [" + ", ".join(reversed(self.stack)) + "]"

stack = Stack()
stack.push('T1')
stack.push('T2')
stack.push('T3')

print('stack:', stack)
print('stack.is_empty():', stack.is_empty())
print('stack.length():', stack.length())
print('stack.top():', stack.top())
print('stack.pop():', stack.pop())
print('stack:', stack)
