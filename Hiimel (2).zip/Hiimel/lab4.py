import numpy as np
import matplotlib.pyplot as plt

def manhattan_distance(x, y):
    assert len(x) == len(y), "Vectors must have the same dimension"
    return sum(abs(a - b) for a, b in zip(x, y))

def initialize_centroids(X, k):
    indices = np.random.choice(len(X), k, replace=False)
    return X[indices]

def assign_clusters(X, centroids):
    clusters = np.zeros(len(X))
    for i, x in enumerate(X):
        distances = [manhattan_distance(x, centroid) for centroid in centroids]
        cluster = np.argmin(distances)
        clusters[i] = cluster
    return clusters

def update_centroids(X, clusters, k):
    centroids = np.zeros((k, X.shape[1]))
    for i in range(k):
        cluster_points = X[clusters == i]
        centroids[i] = np.mean(cluster_points, axis=0)
    return centroids

np.random.seed(4)
X, _ = np.random.randn(1000, 2), None

k = 4

centroids = initialize_centroids(X, k)
for _ in range(100):  
    prev_centroids = centroids
    clusters = assign_clusters(X, centroids)
    centroids = update_centroids(X, clusters, k)
    if np.all(prev_centroids == centroids):
        break


for cluster in range(k):
    cluster_points = X[clusters == cluster]
    plt.scatter(cluster_points[:, 0], cluster_points[:, 1])

for centroid in centroids:
    plt.scatter(centroid[0], centroid[1], c='red', marker='x', s=200)

plt.show()