import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.datasets import cifar10
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Conv2D, MaxPooling2D, UpSampling2D
from tensorflow.keras.optimizers import Adam
from PIL import Image
import os

(x_train, _), (x_test, _) = cifar10.load_data()
x_train = x_train.astype('float32') / 255.
x_test = x_test.astype('float32') / 255.

noise_factor = 0.2
x_train_noisy = np.clip(x_train + noise_factor * np.random.normal(loc=0.0, scale=1.0, size=x_train.shape), 0., 1.)
x_test_noisy = np.clip(x_test + noise_factor * np.random.normal(loc=0.0, scale=1.0, size=x_test.shape), 0., 1.)

input_img = Input(shape=(32, 32, 3))

x = Conv2D(32, (3, 3), activation='relu', padding='same')(input_img)
x = MaxPooling2D((2, 2), padding='same')(x)
x = Conv2D(32, (3, 3), activation='relu', padding='same')(x)
encoded = MaxPooling2D((2, 2), padding='same')(x)

x = Conv2D(32, (3, 3), activation='relu', padding='same')(encoded)
x = UpSampling2D((2, 2))(x)
x = Conv2D(32, (3, 3), activation='relu', padding='same')(x)
x = UpSampling2D((2, 2))(x)
decoded = Conv2D(3, (3, 3), activation='sigmoid', padding='same')(x)

autoencoder = Model(input_img, decoded)
autoencoder.compile(optimizer=Adam(), loss='binary_crossentropy')

autoencoder.fit(x_train_noisy, x_train, epochs=10, batch_size=128, shuffle=True, validation_data=(x_test_noisy, x_test))

img_path = "C:/Users/LENOVO/Documents/Hiimel/SA/cat.png"
img = Image.open(img_path).convert('RGB').resize((32, 32))
img_array = np.array(img).astype("float32") / 255.0
img_array = img_array.reshape((1, 32, 32, 3))

noise = 0.2 * np.random.normal(loc=0.0, scale=1.0, size=img_array.shape)
noisy_img = np.clip(img_array + noise, 0., 1.)

denoised = autoencoder.predict(noisy_img)

fig, axs = plt.subplots(1, 3, figsize=(10, 4))
axs[0].imshow(noisy_img[0])
axs[0].set_title("Noisy")
axs[0].axis('off')

axs[1].imshow(denoised[0])
axs[1].set_title("Denoised")
axs[1].axis('off')

axs[2].imshow(img_array[0])
axs[2].set_title("Original")
axs[2].axis('off')

plt.tight_layout()
plt.show()
