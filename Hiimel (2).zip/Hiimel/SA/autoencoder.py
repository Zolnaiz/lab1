import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
from tensorflow.keras.layers import Input, Dense
from tensorflow.keras.models import Model

input_img = Input(shape=(784,))
encoded = Dense(64, activation='relu')(input_img)
decoded = Dense(784, activation='sigmoid')(encoded)
autoencoder = Model(input_img, decoded)
autoencoder.compile(optimizer='adam', loss='binary_crossentropy')

from tensorflow.keras.datasets import mnist
(x_train, _), (_, _) = mnist.load_data()
x_train = x_train.astype('float32') / 255.
x_train = x_train.reshape((len(x_train), 784))
autoencoder.fit(x_train, x_train, epochs=10, batch_size=256, shuffle=True)

img = Image.open("C:/Users/LENOVO/Documents/Hiimel/SA/cat.png").convert('L')
img = img.resize((28, 28))
img_array = np.array(img).astype("float32") / 255.0
img_array = img_array.reshape(1, 784)

noise = 0.5 * np.random.normal(loc=0.0, scale=1.0, size=img_array.shape)
noisy_img = np.clip(img_array + noise, 0., 1.)

denoised = autoencoder.predict(noisy_img)

plt.figure(figsize=(10, 4))
plt.subplot(1, 3, 1)
plt.imshow(noisy_img.reshape(28, 28), cmap="gray")
plt.title("Noisy")
plt.axis("off")

plt.subplot(1, 3, 2)
plt.imshow(denoised.reshape(28, 28), cmap="gray")
plt.title("Denoised")
plt.axis("off")

plt.subplot(1, 3, 3)
plt.imshow(img_array.reshape(28, 28), cmap="gray")
plt.title("Original")
plt.axis("off")

plt.tight_layout()
plt.show()
