# Diabetes K-Nearest Neighbors vs Decision Tree Classifier

This project implements two machine learning algorithms, K-Nearest Neighbors (KNN) and Decision Tree Classifier, to predict diabetes using the Pima Indians Diabetes dataset. The performance of both classifiers is compared to determine which model performs better on this dataset.

## Project Structure

```
diabetes-knn-vs-dt
├── src
│   ├── knn_classifier.py        # Implements the KNN algorithm
│   ├── decision_tree_classifier.py # Implements the Decision Tree Classifier
│   └── compare_classifiers.py    # Compares the results of KNN and Decision Tree
├── data
│   └── pima-indians-diabetes.csv # Dataset for training and testing
├── requirements.txt              # Lists project dependencies
└── README.md                     # Documentation for the project
```

## Setup Instructions

1. **Clone the repository**:
   ```
   git clone <repository-url>
   cd diabetes-knn-vs-dt
   ```

2. **Install dependencies**:
   It is recommended to use a virtual environment. You can create one using:
   ```
   python -m venv venv
   source venv/bin/activate  # On Windows use `venv\Scripts\activate`
   ```
   Then install the required packages:
   ```
   pip install -r requirements.txt
   ```

## Running the Classifiers

- To run the KNN classifier, execute:
  ```
  python src/knn_classifier.py
  ```

- To run the Decision Tree classifier, execute:
  ```
  python src/decision_tree_classifier.py
  ```

- To compare the results of both classifiers, execute:
  ```
  python src/compare_classifiers.py
  ```

## Interpreting Results

After running the classifiers, you will receive accuracy scores for both models. The comparison script will provide a summary of which model performed better based on accuracy. 

Feel free to explore the code in the `src` directory to understand the implementation details of each classifier.