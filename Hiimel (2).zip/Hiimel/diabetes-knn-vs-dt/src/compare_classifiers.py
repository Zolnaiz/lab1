import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn import metrics

col_names = ['pregnant', 'glucose', 'bp', 'skin', 'insulin', 'bmi', 'pedigree', 'age', 'label']
pima = pd.read_csv("data/pima-indians-diabetes.csv", header=None, names=col_names)

feature_cols = ['pregnant', 'insulin', 'bmi', 'age', 'glucose', 'bp', 'pedigree']
X = pima[feature_cols]
y = pima.label

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=1)

dt_clf = DecisionTreeClassifier()
dt_clf.fit(X_train, y_train)
dt_y_pred = dt_clf.predict(X_test)
dt_accuracy = metrics.accuracy_score(y_test, dt_y_pred)

knn_clf = KNeighborsClassifier()
knn_clf.fit(X_train, y_train)
knn_y_pred = knn_clf.predict(X_test)
knn_accuracy = metrics.accuracy_score(y_test, knn_y_pred)

print("Decision Tree Accuracy:", dt_accuracy)
print("KNN Accuracy:", knn_accuracy)