from collections import Counter


day_1 = ['home', 'school', 'restaurant', 'home']
day_2 = ['home', 'school', 'restaurant', 'home']
days = day_1 + day_2

#1
unique_locations = set(days)
location_count = Counter(days)
most_common_1 = location_count.most_common(1)
print(f"Hamgiin tugeemel 1 uildel {most_common_1}")

#2
pairs = [tuple(days[i:i+2]) for i in range(len(days)-1)]
pair_count = Counter(pairs)
most_common_2 = pair_count.most_common(1)
print(f"Hamgiin tugeemel daraallasan 2 uildel: {most_common_2}")

#3
triplets = [tuple(days[i:i+3]) for i in range(len(days)-2)]
triplet_count = Counter(triplets)
most_common_3 = triplet_count.most_common(1)
print(f"Hamgiin tugeemel daraallasan 3 uildel: {most_common_3}")
