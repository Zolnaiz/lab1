from ultralytics import YOLO
import cv2

model = YOLO(r"C:\path\to\yolov8n.pt")

video_path = r"testvideo.mp4"
cap = cv2.VideoCapture(video_path)

width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
fps = int(cap.get(cv2.CAP_PROP_FPS))

out = cv2.VideoWriter("output.mp4", cv2.VideoWriter_fourcc(*'mp4v'), fps, (width, height))

prev_bus_boxes = []  # Store previous bus coordinates

def is_duplicate(new_box, prev_boxes, threshold=50):
    for box in prev_boxes:
        # Compare center points of boxes
        x1, y1, x2, y2 = box
        cx1, cy1 = (x1 + x2) / 2, (y1 + y2) / 2

        x3, y3, x4, y4 = new_box
        cx2, cy2 = (x3 + x4) / 2, (y3 + y4) / 2

        dist = ((cx1 - cx2)**2 + (cy1 - cy2)**2)**0.5
        if dist < threshold:
            return True
    return False

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    results = model.predict(frame, imgsz=640, conf=0.3, verbose=False)
    annotated_frame = results[0].plot()

    current_bus_boxes = []

    for box in results[0].boxes:
        cls_id = int(box.cls[0].item())
        class_name = results[0].names[cls_id]

        if class_name == "bus":
            coords = [int(x.item()) for x in box.xyxy[0]]
            if not is_duplicate(coords, prev_bus_boxes):
                print("🚌 New bus detected:", coords)
            current_bus_boxes.append(coords)

    prev_bus_boxes = current_bus_boxes  # Save for next frame

    out.write(annotated_frame)
    cv2.imshow("Detection", annotated_frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
out.release()
cv2.destroyAllWindows()
