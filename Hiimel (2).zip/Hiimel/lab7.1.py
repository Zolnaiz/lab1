import easyocr
import pandas as pd
import os
import difflib
import re

reader = easyocr.Reader(['en'], gpu=False)

def extract_text_from_image(image_path):
    result = reader.readtext(image_path, detail=0, paragraph=True)
    return ' '.join(result)

def clean_text(text):
    text = re.sub(r'[^a-zA-Z0-9 .,\'\"\n]', '', text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip().lower()

def evaluate(pred_text, true_text):
    pred = clean_text(pred_text)
    true = clean_text(true_text)
    matcher = difflib.SequenceMatcher(None, true, pred)
    return round(matcher.ratio() * 100, 2)

image_folder = 'images'
image_files = [f for f in os.listdir(image_folder) if f.lower().endswith(('.jpg', '.png'))]

results = []

for file in image_files:
    image_path = os.path.join(image_folder, file)
    txt_path = os.path.join(image_folder, file.rsplit('.', 1)[0] + '.txt')

    predicted_text = extract_text_from_image(image_path)

    try:
        with open(txt_path, 'r', encoding='utf-8') as f:
            ground_truth = f.read()
    except FileNotFoundError:
        print(f"⚠️ Ground truth not found: {txt_path}")
        ground_truth = ""

    if not predicted_text.strip() or not ground_truth.strip():
        similarity = 0.0
    else:
        similarity = evaluate(predicted_text, ground_truth)

    print(f"\n🖼 {file}")
    print(f"🔍 Predicted: {predicted_text.strip()[:100]}...")
    print(f"📌 Ground Truth: {ground_truth.strip()[:100]}...")
    print(f"✅ Similarity: {similarity}%")

    results.append({
        'Image': file,
        'Predicted Text': predicted_text.strip(),
        'Ground Truth': ground_truth.strip(),
        'Similarity (%)': similarity
    })

df = pd.DataFrame(results)
print("\n📊 OCR ҮР ДҮН:")
print(df)

df.to_excel("ocr_results_final.xlsx", index=False)
