import google.generativeai as genai

genai.configure(api_key="AIzaSyBLy_jVdKn9_fOPre-xyopMRFZw-tp3glk")

model = genai.GenerativeModel("gemini-2.0-flash")

problems = [
    "256 * 13 хэд вэ?",
    "Хэрвээ 3 алим 1500₮ бол нэг алим хэдэн төгрөг вэ?",
    "x + 5 = 12, x хэд вэ?",
    "Пифагорын теорем ашиглан 3 ба 4 талтай тэгш өнцөгт гурвалжны гипотенуз ол.",
    "5, 10, 20, ... дарааллын 7 дахь гишүүнийг ол."
]

n=1

for problem in problems:
    print(f"Асуулт: {problem}")
    response = model.generate_content(
        problem,
        generation_config=genai.types.GenerationConfig(
            candidate_count=n,
            temperature=0.7  
        )
    )

    for i, candidate in enumerate(response.candidates, 1):
        print(f"Хариулт {i}: {candidate.content.parts[0].text.strip()}")
    print("-" * 60)
