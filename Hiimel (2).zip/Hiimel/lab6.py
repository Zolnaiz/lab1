# -*- coding: utf-8 -*-
import openai
from openai import OpenAI

client = OpenAI(api_key="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")

def solve_math_problem(prompt):
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "Чи одоо тоо боддог туслах байна. Хэрэглэгчийн асуултанд зөв хариулт гаргаж өг."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.2
    )
    return response.choices[0].message.content

# Туршилтын бодлогууд
problems = [
    "256 * 13 хэд вэ?",
    "Хэрвээ 3 алим 1500₮ бол нэг алим хэдэн төгрөг вэ?",
    "x + 5 = 12, x хэд вэ?",
    "Пифагорын теорем ашиглан 3 ба 4 талтай тэгш өнцөгт гурвалжны гипотенуз ол.",
    "5, 10, 20, ... дарааллын 7 дахь гишүүнийг ол."
]

for problem in problems:
    print(f"Асуулт: {problem}")
    print(f"Хариулт: {solve_math_problem(problem)}")
    print("-" * 50)
